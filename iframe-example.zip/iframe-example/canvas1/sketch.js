function setup() {
  let cnv = createCanvas(windowWidth, windowHeight);
  cnv.parent("canvasContainer")
}

function draw() {
  background(220);
  text(width, width/2, height/2)
}
